#!/usr/bin/env python

# System
import datetime
import time
import pygtk
pygtk.require('2.0')
import gtk
import gtk.gtkgl
from pprint import pprint


#import thread
import gobject
import sys
import os

# Imports
from OpenGL.GL import *
from OpenGL.GLU import *
from pymol import cmd
from pymol_connector import PymolWindow

# GUI 
#from gui.MinimizationWindow          import *  # window 2  - minimization
#from gui.MolecularDynamicsWindow     import *
#
#from gui.FileChooserWindow           import *
#from gui.NewProjectDialog            import *
#from gui.QuantumChemistrySetupDialog import *
#
#from gui.NonBondDialog               import *
#from gui.ScanWindow                  import *
#from gui.pDynamoSelectionsWindow     import pDynamoSelectionWindow
#
#from gui.Scan2dDialog                import *
#
#from gui.TrajectoryDialog            import *
#from gui.WorkSpaceDialog             import WorkSpaceDialog
#
#import TextEditor.TextEditorWindow as TextEditor
#
#from   MatplotGTK.MatplotGTK          import PlotGTKWindow


# pDynamo
#from pDynamoProject  import *
from FileChooserWindow import *
#-------------------------#
#                         #
#   MASTERS TEMP DIR    #
#                         #
#-------------------------#

# get a temporary file directory


global slab
slab    = 50
zoom    = 1.0
angle   = 0.0
sprite  = None
zfactor = 0.005
global clicado, ZeroX, ZeroY, Buffer, Zero_ViewBuffer, Menu
clicado = False
ZeroX   = 0
ZeroY   = 0
Buffer  = 0
Zero_pointerx = 0
Zero_pointery = 0
Zero_ViewBuffer = None
Menu =  True


class MASTERS_main():

    def __init__(self, Session = None):
        
        self.pymol_window = PymolWindow()
        if Session == None:
            self.gui = ''
        else:
            self.gui  = Session.gui
        #print "Creating object"
        ## Create our glarea widget
        #glarea = gtk.gtkgl.DrawingArea(glconfig)
        #glarea.connect_after('realize', init)
        #glarea.connect('configure_event', reshape)
        #glarea.connect('expose_event', draw)
        #glarea.connect('map_event', map)
        #glarea.set_events(glarea.get_events() | gtk.gdk.BUTTON_PRESS_MASK | gtk.gdk.BUTTON_RELEASE_MASK |
        #                  gtk.gdk.POINTER_MOTION_MASK | gtk.gdk.POINTER_MOTION_HINT_MASK | gtk.gdk.KEY_PRESS_MASK)
        #
        #
        #                                                      
        #glarea.connect("button_press_event"  , mousepress)      
        #glarea.connect("button_release_event", mouserelease)  
        #glarea.connect("motion_notify_event" , mousemove)      
        #glarea.connect("scroll_event", slabchange)
        #
        #
        #glarea.set_can_focus(True)
        #
        #import pymol2
        #pymol = pymol2.PyMOL(glarea)
        #glarea.connect_object("button_release_event", show_context_menu, context_menu())
        
        
        
        print '           Intializing MASTERS GUI object          '
        self.home = os.environ.get('HOME')
        self.scratch = os.environ.get('PDYNAMO_SCRATCH')

        #---------------------------------- MASTERS ------------------------------------#
        #                                                                                 #
        self.builder = gtk.Builder()                                                      #
        self.builder.add_from_file(                                                       #
            os.path.join('/home/fernando/programs/MastersGUI2/gui/MASTERSviewer.glade'))                           #
        
        self.win = self.builder.get_object("window1")                                     #
        self.win.show()                                                                   #
        self.builder.connect_signals(self)                                                #
        self.selectedID = None                                                            #
        self.MeasureToolVisible = False                                                   #
        self.builder.get_object('notebook3').hide()
        #---------------------------------------------------------------------------------#

        
        #-------------------- config PyMOL ---------------------#
                                                                #
        pymol = self.pymol_window.pymol
        glarea = self.pymol_window.glarea
        container = self.builder.get_object("container")        #
        pymol.start()                                           #
        cmd = pymol.cmd                                         #
        container.pack_start(glarea)                            #
        glarea.show()                                           #
                                                                #
        #-------------------------------------------------------#
    
        
        
        #-------------------- config PyMOL ---------------------#
        #                                                       #
        pymol.cmd.set("internal_gui", 0)                        #
        pymol.cmd.set("internal_gui_mode", 0)                   #
        pymol.cmd.set("internal_feedback", 0)                   #
        pymol.cmd.set("internal_gui_width", 220)                #
        pymol.cmd.set("cartoon_fancy_helices", 'on')            #  
        sphere_scale = 0.25                                     #
        stick_radius = 0.15                                     #
        label_distance_digits = 4                               #
        mesh_width = 0.3                                        #
        cmd.set('sphere_scale', sphere_scale)                   #
        cmd.set('stick_radius', stick_radius)                   #
        cmd.set('label_distance_digits', label_distance_digits) #
        cmd.set('mesh_width', mesh_width)                       #
        cmd.set("retain_order")         # keep atom ordering    #
        #cmd.bg_color("grey")            # background color      #
        cmd.do("set field_of_view, 70")                         #
        cmd.do("set ray_shadows,off")                           #
        cmd.do('set cartoon_highlight_color, 24')               #
        cmd.set('label_size', 20.00)
        cmd.set('label_color', 'white')
        cmd.set('auto_zoom', 1)                                 #
        #-------------------------------------------------------#
        

              #------------------------------------------------#
              #-                 WindowControl                 #
              #------------------------------------------------#
        ##------------------------------------------------------------#
        #self.window_control = WindowControl(self.builder)            #
        #scale = self.builder.get_object("trajectory_hscale")         #
        #scale.set_range(1, 100)                                      #
        #scale.set_increments(1, 10)                                  #
        #scale.set_digits(0)                                          #
        ##------------------------------------------------------------#

        #--------------------- Setup ComboBoxes ---------------------#
        #                                                            #
        combobox = 'combobox1'                                       #
        combolist = ["Atom", "Residue", "Chain", "Molecule"]         #
        #self.window_control.SETUP_COMBOBOXES(combobox, combolist, 1) #
        #------------------------------------------------------------#
        self.FileChooserWindow = FileChooserWindow()

    def LoadFileInMASTERSViewer (self, filein = None):
        """ Function doc """
        print filein
        cmd.load(filein)
        cmd.show("spheres")                                    
        cmd.hide('lines')
        cmd.show('ribbon')                                     
        cmd.color('blue')
        
        cmd.do('select resn leu')
        cmd.do('color red, sele')
        cmd.do('select resn ala')
        cmd.do('color red, sele')
        cmd.do('select resn ile')
        cmd.do('color red, sele')
        cmd.do('select resn pro')
        cmd.do('color red, sele')
        cmd.do('select resn val')
        cmd.do('color red, sele')
        cmd.do('select resn met')
        cmd.do('color red, sele')
        cmd.do('select resn gly')
        cmd.do('color red, sele')
        cmd.do('select resn cys')
        cmd.do('color red, sele')      
        
    def  on_button_OpenFile_clicked(self, button):
        """ Function doc """
        print 'aqui' 
        builder = self.builder
        filein = self.FileChooserWindow.GetFileName(builder)
        self.LoadFileInMASTERSViewer(filein)


    def run(self):
        gtk.main()



def main():
    MASTERS = MASTERS_main()
    MASTERS.run()
    return 0

if __name__ == '__main__':
	main()
    
    
    



